const questions = require('../../data/questions.js');
const store = require('../../data/store.js');
const LETTERS = ['A', 'B', 'C', 'D', 'E'];
const MODE_TITLES = { seq: '顺序练习', rand: '随机练习', wrong: '错题重练', exam: '模拟考试' };

Page({
  data: {
    score: 0,
    modeText: '',
    right: 0,
    wrong: 0,
    rate: 0,
    review: [],
    allRight: false,
  },

  onLoad() {
    const r = getApp().globalData.result;
    if (!r) {
      wx.reLaunch({ url: '/pages/index/index' });
      return;
    }
    const total = r.total;
    const rate = total ? Math.round(r.right / total * 100) : 0;
    const review = r.wrongList.map(item => {
      const q = questions[item.qid];
      return {
        id: item.qid,
        text: (item.qid + 1) + '. ' + q.q,
        userAns: item.picked !== undefined ? LETTERS[item.picked] : '未作答',
        rightAns: LETTERS[q.answer],
        explain: q.explain,
      };
    });
    this.setData({
      score: r.right * 2,
      modeText: MODE_TITLES[r.mode] + ' · ' + total + ' 题',
      right: r.right,
      wrong: r.wrongList.length,
      rate,
      review,
      allRight: r.wrongList.length === 0,
    });
  },

  retryWrong() {
    const d = store.loadData();
    if (d.wrong.length === 0) {
      wx.showToast({ title: '没有错题，无需重练', icon: 'none' });
      return;
    }
    wx.redirectTo({ url: '/pages/quiz/quiz?mode=wrong' });
  },

  goHome() {
    wx.reLaunch({ url: '/pages/index/index' });
  },
});
