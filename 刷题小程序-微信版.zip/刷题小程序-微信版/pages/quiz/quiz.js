const questions = require('../../data/questions.js');
const store = require('../../data/store.js');
const LETTERS = ['A', 'B', 'C', 'D', 'E'];
const MODE_TITLES = { seq: '顺序练习', rand: '随机练习', wrong: '错题重练', exam: '模拟考试' };

Page({
  data: {
    mode: 'seq',
    modeTitle: '',
    subTitle: '',
    cur: 0,
    counter: '',
    progress: 0,
    qnum: '',
    qtext: '',
    opts: [],
    explainShow: false,
    explainOk: false,
    explainTitle: '',
    explainText: '',
    showPrev: false,
    btnNextText: '下一题',
    showSheet: false,
    sheetCells: [],
    fabOn: true,
    fabX: 0,
    fabY: 0,
    showSettings: false,
    toast: '',
    toastShow: false,
  },

  onLoad(options) {
    const mode = options.mode || 'seq';
    this.mode = mode;
    this.order = this.buildOrder(mode);
    this.answers = {};
    this.examSubmitted = false;
    this.setData({
      mode,
      modeTitle: MODE_TITLES[mode],
      subTitle: mode === 'exam' ? '统一作答后交卷' : '即答即判',
    });
    this.initFab();
    this.renderQ();
  },

  onUnload() {
    clearTimeout(this.toastTimer);
  },

  buildOrder(mode) {
    let idx = questions.map((_, i) => i);
    if (mode === 'rand') idx = this.shuffle(idx);
    if (mode === 'wrong') {
      const d = store.loadData();
      idx = idx.filter(i => d.wrong.indexOf(i) >= 0);
    }
    return idx;
  },

  shuffle(a) {
    a = a.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  },

  renderQ() {
    const qid = this.order[this.data.cur];
    const q = questions[qid];
    const total = this.order.length;
    const picked = this.answers[qid];
    const revealed = this.mode !== 'exam' && picked !== undefined;

    const opts = q.opts.map((text, oi) => {
      let cls = 'opt';
      if (revealed) {
        cls += ' disabled';
        if (oi === q.answer) cls += ' right';
        else if (oi === picked) cls += ' wrong';
        else cls += ' dim';
      } else if (picked === oi) {
        cls += ' picked';
      }
      return { tag: LETTERS[oi], text, cls };
    });

    let explainShow = false, explainOk = false, explainTitle = '', explainText = '';
    if (revealed) {
      explainShow = true;
      explainOk = picked === q.answer;
      explainTitle = explainOk ? '✔ 回答正确' : '✘ 回答错误，正确答案：' + LETTERS[q.answer];
      explainText = q.explain;
    }

    const last = this.data.cur === total - 1;
    this.setData({
      counter: (this.data.cur + 1) + '/' + total,
      progress: Math.round((this.data.cur + 1) / total * 100),
      qnum: '第 ' + (this.data.cur + 1) + ' 题（题库第 ' + (qid + 1) + ' 题）· 1分',
      qtext: q.q,
      opts,
      explainShow,
      explainOk,
      explainTitle,
      explainText,
      showPrev: this.data.cur > 0,
      btnNextText: last ? (this.mode === 'exam' ? '交卷' : '完成') : '下一题',
    });
    this.renderSheet();
  },

  onPick(e) {
    const qid = this.order[this.data.cur];
    const oi = e.currentTarget.dataset.oi;
    this.pick(qid, oi);
  },

  // 统一答题逻辑（点击选项 / 悬浮球选 A~D / 切换选项 均走这里）
  pick(qid, oi) {
    if (this.mode === 'exam') {
      if (this.examSubmitted) return;
      this.answers[qid] = oi;
      this.renderQ();
      return;
    }
    if (this.answers[qid] !== undefined) return; // 练习模式已答锁定
    this.answers[qid] = oi;
    const q = questions[qid];
    const ok = oi === q.answer;
    const d = store.loadData();
    d.total++;
    if (ok) {
      d.right++;
      d.mastered[qid] = 1;
      d.wrong = d.wrong.filter(x => x !== qid);
    } else {
      if (d.wrong.indexOf(qid) < 0) d.wrong.push(qid);
    }
    store.saveData(d);
    this.renderQ();
  },

  onNext() {
    if (this.data.cur < this.order.length - 1) {
      this.setData({ cur: this.data.cur + 1 });
      this.renderQ();
      return;
    }
    if (this.mode === 'exam') {
      this.submitExam();
    } else {
      wx.navigateBack();
    }
  },

  onPrev() {
    if (this.data.cur > 0) {
      this.setData({ cur: this.data.cur - 1 });
      this.renderQ();
    }
  },

  goBack() {
    wx.navigateBack();
  },

  /* ---------- 答题卡 ---------- */
  renderSheet() {
    const cells = this.order.map((qid, idx) => {
      const picked = this.answers[qid];
      let cls = 'cell';
      if (idx === this.data.cur) cls += ' cur';
      if (this.mode === 'exam') {
        if (picked !== undefined) cls += ' done';
      } else if (picked !== undefined) {
        cls += picked === questions[qid].answer ? ' ok' : ' bad';
      }
      return { num: idx + 1, cls };
    });
    this.setData({ sheetCells: cells });
  },

  openSheet() {
    this.renderSheet();
    this.setData({ showSheet: true });
  },

  closeSheet() {
    this.setData({ showSheet: false });
  },

  onSheetCell(e) {
    this.setData({ cur: e.currentTarget.dataset.idx, showSheet: false });
    this.renderQ();
  },

  /* ---------- 交卷 ---------- */
  submitExam() {
    let right = 0;
    const wrongList = [];
    const d = store.loadData();
    this.order.forEach(qid => {
      const q = questions[qid];
      const picked = this.answers[qid];
      if (picked === q.answer) {
        right++;
        d.mastered[qid] = 1;
        d.wrong = d.wrong.filter(x => x !== qid);
      } else {
        wrongList.push({ qid, picked });
        if (d.wrong.indexOf(qid) < 0) d.wrong.push(qid);
      }
    });
    d.total += this.order.length;
    d.right += right;
    store.saveData(d);
    this.examSubmitted = true;

    getApp().globalData.result = { mode: this.mode, total: this.order.length, right, wrongList };
    wx.redirectTo({ url: '/pages/result/result' });
  },

  /* ---------- 悬浮球 ---------- */
  initFab() {
    const cfg = store.loadFab();
    const sys = wx.getSystemInfoSync();
    const W = sys.screenWidth, H = sys.screenHeight;
    let x, y;
    if (cfg.pos && typeof cfg.pos.left === 'number') {
      x = cfg.pos.left; y = cfg.pos.top;
    } else {
      x = W - 56 - 16;
      y = H - 56 - 110;
    }
    this.setData({ fabOn: cfg.show, fabX: x, fabY: y });
  },

  onFabStart(e) {
    const t = e.touches[0];
    this.fabTS = { x: t.clientX, y: t.clientY, t: Date.now(), drag: false, dir: null, moved: false };
  },

  onFabMove(e) {
    const ts = this.fabTS;
    if (!ts) return;
    const t = e.touches[0];
    const dx = t.clientX - ts.x, dy = t.clientY - ts.y;
    const dist = Math.hypot(dx, dy);
    if (!ts.moved && dist > 12) {
      ts.moved = true;
      if (Date.now() - ts.t > 260) ts.drag = true;
      else ts.dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
    }
    if (ts.drag) {
      const sys = wx.getSystemInfoSync();
      const R = 28;
      const L = Math.min(Math.max(t.clientX - R, 0), sys.screenWidth - R * 2);
      const T = Math.min(Math.max(t.clientY - R, 0), sys.screenHeight - R * 2);
      this.setData({ fabX: L, fabY: T });
    }
  },

  onFabEnd() {
    const ts = this.fabTS;
    if (!ts) return;
    if (!ts.moved) this.trigger('tap');
    else if (ts.drag) this.saveFabPos();
    else if (ts.dir) this.trigger(ts.dir);
    this.fabTS = null;
  },

  saveFabPos() {
    const cfg = store.loadFab();
    cfg.pos = { left: this.data.fabX, top: this.data.fabY };
    store.saveFab(cfg);
  },

  trigger(dir) {
    const cfg = store.loadFab();
    const act = cfg.gestures[dir];
    if (act) this.doAction(act);
    if (act) {
      const a = store.ACTIONS.find(x => x.v === act);
      this.showToast(a ? a.l : act);
    }
  },

  showToast(msg) {
    this.setData({ toast: msg, toastShow: true });
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => this.setData({ toastShow: false }), 900);
  },

  doAction(name) {
    const qid = this.order[this.data.cur];
    if (qid === undefined) return;
    switch (name) {
      case 'next': this.onNext(); break;
      case 'prev': this.onPrev(); break;
      case 'selA': this.selOpt(0); break;
      case 'selB': this.selOpt(1); break;
      case 'selC': this.selOpt(2); break;
      case 'selD': this.selOpt(3); break;
      case 'prevOpt': this.optStep(-1); break;
      case 'nextOpt': this.optStep(1); break;
      case 'sheet': this.openSheet(); break;
      case 'submit':
        if (this.mode === 'exam' && !this.examSubmitted) this.submitExam();
        break;
    }
  },

  selOpt(oi) {
    const qid = this.order[this.data.cur];
    if (oi < questions[qid].opts.length) this.pick(qid, oi);
  },

  optStep(dir) {
    const qid = this.order[this.data.cur];
    const q = questions[qid];
    if (this.mode !== 'exam' && this.answers[qid] !== undefined) return;
    const n = q.opts.length;
    const cur = this.answers[qid];
    const next = cur === undefined ? (dir === 1 ? 0 : n - 1) : (cur + dir + n) % n;
    this.pick(qid, next);
  },

  /* ---------- 设置 ---------- */
  openSettings() {
    this.setData({ showSettings: true });
  },

  onFabClose() {
    this.setData({ showSettings: false });
  },

  onFabChange() {
    const cfg = store.loadFab();
    this.setData({ fabOn: cfg.show });
  },
});
