const questions = require('../../data/questions.js');
const store = require('../../data/store.js');

Page({
  data: {
    total: 0,
    mastered: 0,
    wrong: 0,
    showSettings: false,
  },

  onShow() {
    this.renderStats();
  },

  renderStats() {
    const d = store.loadData();
    this.setData({
      total: questions.length,
      mastered: Object.keys(d.mastered).length,
      wrong: d.wrong.length,
    });
  },

  start(mode) {
    if (mode === 'wrong') {
      const d = store.loadData();
      if (d.wrong.length === 0) {
        wx.showToast({ title: '暂无错题，先去刷几题吧', icon: 'none' });
        return;
      }
    }
    wx.navigateTo({ url: '/pages/quiz/quiz?mode=' + mode });
  },

  startSeq() { this.start('seq'); },
  startRand() { this.start('rand'); },
  startWrong() { this.start('wrong'); },
  startExam() { this.start('exam'); },

  openSettings() { this.setData({ showSettings: true }); },
  onFabClose() { this.setData({ showSettings: false }); },
  onFabChange() {},

  resetData() {
    wx.showModal({
      title: '提示',
      content: '确定清空全部学习记录（错题、掌握情况）？',
      success: (res) => {
        if (res.confirm) {
          store.saveData({ wrong: [], mastered: {}, right: 0, total: 0 });
          this.renderStats();
        }
      },
    });
  },
});
