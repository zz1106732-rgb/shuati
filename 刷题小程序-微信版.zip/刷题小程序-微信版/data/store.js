// 本地存储工具 + 悬浮球配置常量
const KEY_DATA = 'sq_data_v1';
const KEY_FAB = 'sq_fab_v1';

const DEFAULT_GESTURES = { tap: 'next', up: 'prev', down: 'next', left: 'prevOpt', right: 'nextOpt' };

const GESTURES = [
  { key: 'tap', label: '点击圆心' },
  { key: 'up', label: '上滑' },
  { key: 'down', label: '下滑' },
  { key: 'left', label: '左滑' },
  { key: 'right', label: '右滑' },
];

const ACTIONS = [
  { v: 'next', l: '下一题' },
  { v: 'prev', l: '上一题' },
  { v: 'selA', l: '选择 A' },
  { v: 'selB', l: '选择 B' },
  { v: 'selC', l: '选择 C' },
  { v: 'selD', l: '选择 D' },
  { v: 'prevOpt', l: '上一个选项' },
  { v: 'nextOpt', l: '下一个选项' },
  { v: 'sheet', l: '打开答题卡' },
  { v: 'submit', l: '交卷（考试）' },
];

function loadData() {
  const d = wx.getStorageSync(KEY_DATA);
  if (d && Array.isArray(d.wrong) && d.mastered && typeof d.mastered === 'object') return d;
  return { wrong: [], mastered: {}, right: 0, total: 0 };
}

function saveData(d) {
  wx.setStorageSync(KEY_DATA, d);
}

function loadFab() {
  const c = wx.getStorageSync(KEY_FAB);
  if (c && c.gestures) {
    return {
      show: c.show !== false,
      gestures: Object.assign({}, DEFAULT_GESTURES, c.gestures),
      pos: c.pos || null,
    };
  }
  return { show: true, gestures: Object.assign({}, DEFAULT_GESTURES), pos: null };
}

function saveFab(c) {
  wx.setStorageSync(KEY_FAB, c);
}

module.exports = { DEFAULT_GESTURES, GESTURES, ACTIONS, loadData, saveData, loadFab, saveFab };
