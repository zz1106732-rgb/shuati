App({
  globalData: {
    result: null, // 考试结果（quiz -> result 传参）
  },
});
