const store = require('../../data/store.js');

Component({
  properties: {
    show: { type: Boolean, value: false },
  },

  data: {
    fabOn: true,
    rows: [],
  },

  lifetimes: {
    attached() {
      this.render();
    },
  },

  methods: {
    render() {
      const cfg = store.loadFab();
      const labels = store.ACTIONS.map(a => a.l);
      const rows = store.GESTURES.map(g => {
        const val = cfg.gestures[g.key];
        let index = store.ACTIONS.findIndex(a => a.v === val);
        if (index < 0) index = 0;
        return { key: g.key, label: g.label, options: labels, index };
      });
      this.setData({ fabOn: cfg.show, rows });
    },

    onToggle(e) {
      const cfg = store.loadFab();
      cfg.show = e.detail.value;
      store.saveFab(cfg);
      this.setData({ fabOn: cfg.show });
      this.triggerEvent('change');
    },

    onPick(e) {
      const key = e.currentTarget.dataset.key;
      const index = e.detail.value;
      const cfg = store.loadFab();
      cfg.gestures[key] = store.ACTIONS[index].v;
      store.saveFab(cfg);
      this.render();
      this.triggerEvent('change');
    },

    onReset() {
      const cfg = store.loadFab();
      cfg.gestures = Object.assign({}, store.DEFAULT_GESTURES);
      store.saveFab(cfg);
      this.render();
      this.triggerEvent('change');
    },

    onClose() {
      this.triggerEvent('close');
    },
  },
});
